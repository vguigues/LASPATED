from .data_agg import DataAggregator

__version__ = '0.1.0'
