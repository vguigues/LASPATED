# LASPATED: Library for Analysis of Spatio-Temporal Discrete Data

LASPATED is a library for the analysis of spatio-temporal data. Its main features are flexible time discretizations and several types of space discretization. For more information check our [GitHub repository](https://github.com/vguigues/LASPATED/)