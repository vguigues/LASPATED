# laspated/__init__.py
from .data_agg import DataAggregator